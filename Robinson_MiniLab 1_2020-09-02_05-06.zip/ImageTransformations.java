public class ImageTransformations {
    
    /**
     * Returns a grayscale version of originalImage as a 2D Pixel array..
     */
    public static Pixel[][] convertToGrayscale(Pixel[][] originalImage) {
        Pixel[][] grayImage = new Pixel[originalImage.length][originalImage[0].length];
            for(int row = 0; row < grayImage.length; row++){
                for(int col = 0; col < grayImage [0].length; col++){
                    Pixel P = originalImage[row][col];
                    int brightness = P.getBrightness();
                    
                    Pixel grayPixel = new Pixel(brightness, brightness, brightness);
                    grayImage[row][col] = grayPixel;
                }
            }
            return grayImage;
    }
    
    /**
     * Returns a vertically-mirrored version of originalImage as a new 2D Pixel array.
     */
    public static Pixel[][] mirrorVertically(Pixel[][] originalImage) {
        Pixel[][] newImage = new Pixel[originalImage.length][originalImage[0].length];
        for(int r = 0; r < originalImage.length; r++){
            for(int c = 0; c < originalImage[0].length; c++){
                newImage[r][originalImage[0].length - 1 - c] = originalImage[r][c];
            }
        }
        return newImage;
    }
    
    /**
     * Returns a clockwise-rotated version of originalImage as a new 2D Pixel array.
     */
    public static Pixel[][] rotateClockwise(Pixel[][] originalImage) {
        Pixel[][] clock = new Pixel[originalImage[0].length][originalImage.length];
            for(int r = 0; r < originalImage.length; r++){
                for(int c = 0; c < originalImage[0].length; c++){
                    clock[c][originalImage.length - 1 - r] = originalImage[r][c];
                }
            }
        return clock;
    }
    
    public static void main(String[] args) {
        // Read miners.png into a 2D Pixel array.
        Picture picture = new Picture("miners.png");
        Pixel[][] originalImage = picture.getImageMatrix();
        
        Pixel[][]gray = convertToGrayscale(originalImage);
        Picture grayResult = new Picture(gray);
        
       
        
        Pixel[][] mirrored = mirrorVertically(gray);
        Picture mirrorResult = new Picture(mirrored);
        
        
        Pixel[][] Result = rotateClockwise(mirrored);
        Picture result = new Picture(Result);
        result.save("miners_Result.png");
        // TODO: Fix the image by using your convertToGrayscale, mirrorVertically, and
        // rotateClcokwise methods.

        // TODO: To save your image, uncomment the lines below and add your Pixel array as the
        // argument to the Picture constructor.
        // Picture result = new Picture(/*put your 2D Pixel array here*/);
        // result.save("miners_fixed.png");
    }
}